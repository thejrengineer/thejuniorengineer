﻿// ============================================================
// Ollama Mail -- Background Service Worker
// NOTE: Requests must include Origin: http://localhost header
//       to pass Ollama's CORS origin check (v0.1.45+).
//       Service workers can set custom Origin via a workaround.
// ============================================================

// Headers that tell Ollama this is a trusted localhost request
const OLLAMA_HEADERS = {
  'Content-Type':  'application/json',
  'Origin':        'http://localhost',
  'Referer':       'http://localhost/'
};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

  if (request.action === 'listModels' || request.action === 'autoStartOllama') {
    fetchModels(request.ollamaUrl || 'http://localhost:11434')
      .then(models => sendResponse({ success: true, models }))
      .catch(err   => sendResponse({ success: false, error: err.message, is403: err.is403 }));
    return true;
  }

  if (request.action === 'callOllama') {
    callOllamaAPI(request.ollamaUrl, request.model, request.prompt)
      .then(reply => sendResponse({ success: true, reply }))
      .catch(err  => sendResponse({ success: false, error: err.message, is403: err.is403 }));
    return true;
  }
});

// -- Fetch installed models ------------------------------------
async function fetchModels(ollamaUrl) {
  let res;
  try {
    res = await fetch(`${ollamaUrl}/api/tags`, {
      headers: OLLAMA_HEADERS,
      signal: AbortSignal.timeout(5000)
    });
  } catch (e) {
    throw Object.assign(new Error('Ollama not running. Start it: ollama serve'), { is403: false });
  }

  if (res.status === 403) {
    const err = new Error('CORS_403');
    err.is403 = true;
    throw err;
  }
  if (!res.ok) throw new Error(`HTTP ${res.status}`);

  const data = await res.json();
  return (data.models || []).map(m => m.name);
}

// -- Generate email reply --------------------------------------
async function callOllamaAPI(ollamaUrl, model, prompt) {
  let res;
  try {
    res = await fetch(`${ollamaUrl}/api/generate`, {
      method: 'POST',
      headers: OLLAMA_HEADERS,
      body: JSON.stringify({
        model, prompt, stream: false,
        options: { temperature: 0.7, top_p: 0.9 }
      })
    });
  } catch (e) {
    throw new Error('Cannot connect to Ollama. Run: ollama serve');
  }

  if (res.status === 403) {
    const err = new Error('CORS_403');
    err.is403 = true;
    throw err;
  }
  if (res.status === 404) {
    throw new Error(`Model "${model}" not found. Run: ollama pull ${model}`);
  }
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`Ollama error ${res.status}: ${body.slice(0, 100)}`);
  }

  const data  = await res.json();
  const reply = (data.response || '').trim();
  if (!reply) throw new Error('Empty response from Ollama. Try a different model.');
  return reply;
}