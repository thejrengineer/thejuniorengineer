﻿#!/usr/bin/env python3
"""
Ollama Mail -- Native Messaging Bridge
Runs as a Chrome Native Messaging Host.
Handles: start_ollama, list_models, get_status
"""

import sys
import json
import struct
import subprocess
import threading
import os
import time

# ── Native Messaging I/O ────────────────────────────────────

def read_message():
    """Read a native message from Chrome (4-byte LE length prefix + JSON)."""
    raw_len = sys.stdin.buffer.read(4)
    if not raw_len or len(raw_len) < 4:
        return None
    msg_len = struct.unpack('<I', raw_len)[0]
    raw_msg = sys.stdin.buffer.read(msg_len)
    return json.loads(raw_msg.decode('utf-8'))

def send_message(data):
    """Send a native message to Chrome (4-byte LE length prefix + JSON)."""
    encoded = json.dumps(data, ensure_ascii=False).encode('utf-8')
    sys.stdout.buffer.write(struct.pack('<I', len(encoded)))
    sys.stdout.buffer.write(encoded)
    sys.stdout.buffer.flush()

# ── Ollama helpers ──────────────────────────────────────────

def is_ollama_running():
    """Check if ollama serve is already running via HTTP."""
    import urllib.request
    try:
        req = urllib.request.urlopen('http://localhost:11434/api/tags', timeout=2)
        data = json.loads(req.read().decode())
        models = [m['name'] for m in data.get('models', [])]
        return True, models
    except Exception:
        return False, []

def start_ollama_serve():
    """Launch ollama serve in background (Windows: minimized console)."""
    try:
        if sys.platform == 'win32':
            CREATE_NO_WINDOW = 0x08000000
            subprocess.Popen(
                ['ollama', 'serve'],
                creationflags=subprocess.DETACHED_PROCESS | CREATE_NO_WINDOW,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                close_fds=True
            )
        else:
            subprocess.Popen(
                ['ollama', 'serve'],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True
            )
        return True
    except FileNotFoundError:
        return False
    except Exception:
        return False

def get_models_via_cli():
    """Run 'ollama list' and parse model names."""
    try:
        result = subprocess.run(
            ['ollama', 'list'],
            capture_output=True, text=True, timeout=10
        )
        lines = result.stdout.strip().splitlines()
        models = []
        for line in lines[1:]:  # skip header
            parts = line.split()
            if parts:
                models.append(parts[0])
        return models
    except Exception:
        return []

# ── Main action dispatcher ──────────────────────────────────

def handle_message(msg):
    action = msg.get('action', '')

    if action == 'ping':
        send_message({'ok': True, 'version': '1.1'})

    elif action == 'get_status':
        running, models = is_ollama_running()
        send_message({'running': running, 'models': models})

    elif action == 'start_and_list':
        # 1. Check if already running
        running, models = is_ollama_running()

        if running:
            send_message({'started': False, 'already_running': True, 'models': models})
            return

        # 2. Try to start ollama serve
        launched = start_ollama_serve()
        if not launched:
            send_message({'started': False, 'error': 'ollama not found in PATH'})
            return

        # 3. Wait up to 8 seconds for it to come online
        for _ in range(16):
            time.sleep(0.5)
            running, models = is_ollama_running()
            if running:
                break

        if running:
            send_message({'started': True, 'models': models})
        else:
            # Fallback: try ollama list via CLI
            cli_models = get_models_via_cli()
            send_message({'started': True, 'models': cli_models, 'via_cli': True})

    elif action == 'list_models':
        running, models = is_ollama_running()
        if not running:
            cli_models = get_models_via_cli()
            send_message({'models': cli_models, 'via_cli': True})
        else:
            send_message({'models': models})

    else:
        send_message({'error': f'unknown action: {action}'})

# ── Entry point ─────────────────────────────────────────────

def main():
    while True:
        msg = read_message()
        if msg is None:
            break
        try:
            handle_message(msg)
        except Exception as e:
            send_message({'error': str(e)})

if __name__ == '__main__':
    main()