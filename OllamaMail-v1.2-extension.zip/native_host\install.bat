﻿@echo off
title Ollama Mail -- Native Host Installer
color 0A
echo.
echo  =====================================================
echo   Ollama Mail - Native Bridge Installer
echo  =====================================================
echo.

REM --- Get Extension ID from user ---
echo  STEP 1: Get your Extension ID from chrome://extensions
echo  (Enable Developer Mode, load unpacked, copy the ID)
echo.
set /p EXT_ID="  Paste your Extension ID here: "

if "%EXT_ID%"=="" (
    echo  ERROR: No extension ID provided. Exiting.
    pause
    exit /b 1
)

REM --- Update the manifest JSON with real extension ID ---
set "MANIFEST_PATH=c:\Users\amitk\Desktop\resume\Amit Resume\ollamaemail\native_host\com.ollamamail.bridge.json"
set "ALLOWED=chrome-extension://%EXT_ID%/"

powershell -Command "(Get-Content '%MANIFEST_PATH%') -replace 'chrome-extension://REPLACE_WITH_EXTENSION_ID/', 'chrome-extension://%EXT_ID%/' | Set-Content '%MANIFEST_PATH%'"

echo.
echo  STEP 2: Registering native host in Windows registry...

reg add "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.ollamamail.bridge" /ve /t REG_SZ /d "c:\Users\amitk\Desktop\resume\Amit Resume\ollamaemail\native_host\com.ollamamail.bridge.json" /f

if %ERRORLEVEL%==0 (
    echo.
    echo  [SUCCESS] Native host registered!
    echo.
    echo  STEP 3: Reload your extension at chrome://extensions
    echo  Then click the extension icon -- Ollama will auto-start!
    echo.
) else (
    echo  [ERROR] Registry write failed. Try running as Administrator.
)

pause