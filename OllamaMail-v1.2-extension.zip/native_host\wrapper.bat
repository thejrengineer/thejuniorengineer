﻿@echo off
C:\Python312\python.exe "c:\Users\amitk\Desktop\resume\Amit Resume\ollamaemail\native_host\ollama_bridge.py"