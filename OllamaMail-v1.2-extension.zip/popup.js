﻿// ============================================================
// Ollama Mail -- Popup Script  
// Polls Ollama HTTP API, detects 403 origin block, guides fix
// ============================================================

const DEFAULT_URL = 'http://localhost:11434';
const DEFAULT_SETTINGS = { ollamaUrl: DEFAULT_URL, model: '', tone: 'professional', language: 'English' };

let pollTimer = null;

function getFullUrl() {
  const v = (document.getElementById('ollamaUrlShort').value || '').trim().replace(/\/$/, '');
  return v.startsWith('http') ? v : `http://${v || 'localhost:11434'}`;
}
function setShortUrl(full) {
  document.getElementById('ollamaUrlShort').value = (full || DEFAULT_URL).replace(/^https?:\/\//, '');
}
function setStatus(state, label, sub) {
  document.getElementById('statusIndicator').className = `status-indicator ${state}`;
  document.getElementById('statusLabel').textContent = label;
  if (sub !== undefined) document.getElementById('statusSub').textContent = sub;
}
function setSpinning(on) {
  document.getElementById('refreshBtn').classList.toggle('spinning', on);
}
function setModelLoading(loading) {
  const w = document.getElementById('modelSelectWrap');
  w.style.opacity = loading ? '0.5' : '1';
  w.style.pointerEvents = loading ? 'none' : '';
}

// Which banner to show: 'none' | 'notrunning' | 'cors403'
function showBanner(type) {
  document.getElementById('bannerNotRunning').style.display = (type === 'notrunning') ? 'flex' : 'none';
  document.getElementById('banner403').style.display = (type === 'cors403') ? 'flex' : 'none';
}

function sendBg(msg) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage(msg, res => {
      if (chrome.runtime.lastError) resolve({ success: false, error: chrome.runtime.lastError.message });
      else resolve(res || { success: false });
    });
  });
}

async function tryConnect(savedModel) {
  const url = getFullUrl();
  const res = await sendBg({ action: 'listModels', ollamaUrl: url });

  if (!res.success) {
    if (res.is403) {
      setStatus('error', 'Blocked by Ollama (403)', 'Need to allow extension origin');
      showBanner('cors403');
      setModelLoading(false);
      populateDropdown([], savedModel);
      renderTags([], 'error');
      return 'blocked';
    }
    setStatus('error', 'Ollama not running', 'Start it: ollama serve');
    showBanner('notrunning');
    setModelLoading(false);
    populateDropdown([], savedModel);
    renderTags([], 'error');
    return false;
  }

  const models = res.models || [];
  showBanner('none');
  setModelLoading(false);

  if (!models.length) {
    setStatus('connected', 'Ollama running - no models', 'Pull one: ollama pull gemma3:4b');
    populateDropdown([], savedModel);
    renderTags([], 'none');
    return 'nomodel';
  }

  const preview = models.map(m => m.split(':')[0]).slice(0, 3).join(', ') + (models.length > 3 ? '...' : '');
  setStatus('connected', `Connected  \u00b7  ${models.length} model${models.length > 1 ? 's' : ''} ready`, preview);
  populateDropdown(models, savedModel);
  renderTags(models);
  return true;
}

function startPolling(savedModel) {
  stopPolling();
  pollTimer = setInterval(async () => {
    const ok = await tryConnect(savedModel || document.getElementById('model').value);
    if (ok === true) stopPolling();
  }, 3000);
}
function stopPolling() {
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
}

async function detectAndConnect(savedModel) {
  stopPolling();
  setStatus('loading', 'Checking Ollama\u2026', `Connecting to ${getFullUrl().replace('http://', '')}`);
  setSpinning(true);
  setModelLoading(true);
  showBanner('none');

  const result = await tryConnect(savedModel);
  setSpinning(false);

  // Poll if not running (auto-detect when user starts Ollama)
  if (result === false) startPolling(savedModel);
}

function populateDropdown(models, savedModel) {
  const sel = document.getElementById('model');
  if (!models.length) { sel.innerHTML = '<option value="">No models detected</option>'; return; }
  sel.innerHTML = models.map(m => `<option value="${m}" ${m === savedModel ? 'selected' : ''}>${m}</option>`).join('');
  if (!models.includes(savedModel)) { sel.value = models[0]; chrome.storage.sync.set({ model: models[0] }); }
}

function renderTags(models, state) {
  const c = document.getElementById('modelTags');
  c.innerHTML = '';
  if (state === 'error' || state === 'none') {
    const t = document.createElement('span');
    t.className = 'model-tag red';
    t.textContent = state === 'error' ? 'Cannot reach Ollama' : 'No models installed';
    c.appendChild(t); return;
  }
  models.forEach(m => { const t = document.createElement('span'); t.className = 'model-tag'; t.textContent = m.split(':')[0]; c.appendChild(t); });
}

// -- Init --
document.addEventListener('DOMContentLoaded', async () => {
  const data = await new Promise(r => chrome.storage.sync.get(DEFAULT_SETTINGS, r));
  setShortUrl(data.ollamaUrl);
  document.getElementById('language').value = data.language || 'English';
  const toneEl = document.querySelector(`input[name="tone"][value="${data.tone}"]`);
  if (toneEl) toneEl.checked = true;
  else document.getElementById('tone-professional').checked = true;
  await detectAndConnect(data.model);
});

document.getElementById('refreshBtn').addEventListener('click', () => detectAndConnect(document.getElementById('model').value));
document.getElementById('ollamaUrlShort').addEventListener('blur', () => detectAndConnect(document.getElementById('model').value));
document.getElementById('model').addEventListener('change', () => { const m = document.getElementById('model').value; if (m) chrome.storage.sync.set({ model: m }); });

// Copy "ollama serve" command
document.getElementById('copyCmdBtn').addEventListener('click', () => {
  navigator.clipboard.writeText('ollama serve');
  const btn = document.getElementById('copyCmdBtn');
  btn.textContent = 'Copied!'; btn.classList.add('copied');
  setTimeout(() => { btn.textContent = 'Copy'; btn.classList.remove('copied'); }, 2000);
});

// Copy the OLLAMA_ORIGINS fix command (PowerShell)
document.getElementById('copyFixBtn').addEventListener('click', () => {
  const cmd = '$env:OLLAMA_ORIGINS="*"; ollama serve';
  navigator.clipboard.writeText(cmd);
  const btn = document.getElementById('copyFixBtn');
  btn.textContent = 'Copied!'; btn.classList.add('copied');
  setTimeout(() => { btn.textContent = 'Copy Fix'; btn.classList.remove('copied'); }, 2500);
});

// Save
document.getElementById('saveBtn').addEventListener('click', () => {
  const tone = document.querySelector('input[name="tone"]:checked');
  chrome.storage.sync.set({
    ollamaUrl: getFullUrl(),
    model: document.getElementById('model').value.trim(),
    tone: tone ? tone.value : 'professional',
    language: document.getElementById('language').value
  }, () => {
    const btn = document.getElementById('saveBtn');
    const sp = btn.querySelector('span');
    btn.classList.add('saved'); sp.textContent = 'Saved!';
    setTimeout(() => { btn.classList.remove('saved'); sp.textContent = 'Save Settings'; }, 2000);
  });
});

window.addEventListener('unload', stopPolling);