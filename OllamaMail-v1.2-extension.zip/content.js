// ============================================================
// Ollama Gmail Reply Assistant -- Content Script (v2)
// Uses a floating button -- works regardless of Gmail DOM changes
// ============================================================

let settings = {
  model:     '',                       // intentionally empty — auto-detected on load
  ollamaUrl: 'http://localhost:11434',
  tone:      'professional',
  language:  'English'
};

// Load settings, then auto-detect model if none is saved yet
function loadSettings() {
  if (!isRuntimeValid()) return;
  chrome.storage.sync.get(['model', 'ollamaUrl', 'tone', 'language'], (data) => {
    if (chrome.runtime.lastError) return;
    if (data.ollamaUrl) settings.ollamaUrl = data.ollamaUrl;
    if (data.tone)      settings.tone      = data.tone;
    if (data.language)  settings.language  = data.language;

    if (data.model) {
      // User already picked a model from popup — use it
      settings.model = data.model;
    } else {
      // No model saved yet → auto-fetch the first installed Ollama model
      autoDetectModel();
    }
  });
}

// Ask background to list models, pick the first one available
function autoDetectModel() {
  if (!isRuntimeValid()) return;
  chrome.runtime.sendMessage(
    { action: 'listModels', ollamaUrl: settings.ollamaUrl },
    (res) => {
      if (chrome.runtime.lastError) return;
      if (res && res.success && res.models && res.models.length > 0) {
        settings.model = res.models[0];
        // Persist so popup also reflects the auto-detected model
        chrome.storage.sync.set({ model: res.models[0] });
        console.log('[Ollama Extension] Auto-detected model:', res.models[0]);
      } else {
        console.warn('[Ollama Extension] No models found. Please run: ollama pull <model>');
      }
    }
  );
}

loadSettings();

// -- Runtime validity guard ------------------------------------
// When extension reloads while Gmail tab is open, chrome.runtime
// becomes stale. This check prevents the "Cannot read properties
// of undefined (reading 'sendMessage')" crash.
function isRuntimeValid() {
  try {
    return !!(chrome && chrome.runtime && chrome.runtime.id);
  } catch (e) {
    return false;
  }
}

// -- Create floating button once --------------------------------
function createFloatingButton() {
  if (document.getElementById('ollama-fab')) return;

  const fab = document.createElement('div');
  fab.id = 'ollama-fab';
  fab.innerHTML = `
    <div id="ollama-fab-btn" title="Generate reply with Ollama AI">
      <span id="ollama-fab-icon">&#129302;</span>
      <span id="ollama-fab-label">Reply with Ollama</span>
    </div>
    <div id="ollama-fab-status"></div>
  `;
  document.body.appendChild(fab);
  document.getElementById('ollama-fab-btn').addEventListener('click', onFabClick);
}

// -- Show/hide fab based on whether we are in an email thread ---
function updateFabVisibility() {
  const fab = document.getElementById('ollama-fab');
  if (!fab) return;
  const emailBody = getEmailBody();
  if (emailBody && emailBody.length > 20) {
    fab.style.display = 'flex';
  } else {
    fab.style.display = 'none';
  }
}

// -- Get email body text (multiple fallback selectors) ----------
function getEmailBody() {
  const selectors = [
    '.a3s.aiL',
    '.a3s',
    '[data-message-id] .ii.gt',
    '.ii.gt .a3s',
    '.gs .ii .a3s',
    '[role="main"] .ii',
  ];
  for (const sel of selectors) {
    const els = document.querySelectorAll(sel);
    if (els.length > 0) {
      const el   = els[els.length - 1];
      const text = (el.innerText || el.textContent || '').trim();
      if (text.length > 20) return text.slice(0, 3000);
    }
  }
  return null;
}

// -- Open Gmail reply compose box --------------------------------
function openReplyBox() {
  const replySelectors = [
    '[data-tooltip="Reply"]',
    '[aria-label="Reply"]',
    'button[aria-label*="Reply"]',
    '.ams[data-tooltip="Reply"]',
    '[jsaction*="reply"]',
  ];
  for (const sel of replySelectors) {
    const btns = document.querySelectorAll(sel);
    if (btns.length > 0) { btns[btns.length - 1].click(); return true; }
  }
  const allSpans = document.querySelectorAll('span[role="link"]');
  for (const span of allSpans) {
    if (span.textContent.trim() === 'Reply') { span.click(); return true; }
  }
  return false;
}

// -- Find the active compose/reply box --------------------------
function findComposeBox() {
  const selectors = [
    'div[role="textbox"][contenteditable="true"]',
    '[contenteditable="true"][aria-label*="Message Body"]',
    '[contenteditable="true"][aria-label*="message"]',
    '.Am.Al.editable',
    '[g_editable="true"]',
    '.editable[contenteditable="true"]',
  ];
  for (const sel of selectors) {
    const boxes = document.querySelectorAll(sel);
    if (boxes.length > 0) return boxes[boxes.length - 1];
  }
  return null;
}

// -- Inject reply text into compose box -------------------------
function injectTextIntoCompose(composeBox, text) {
  composeBox.focus();
  const existingText  = composeBox.innerText.trim();
  const isPlaceholder = existingText === '' ||
    existingText.toLowerCase().includes('brt') ||
    existingText.toLowerCase().includes('--');

  const lines       = text.split('\n');
  const htmlContent = lines.map(l => `<div>${l || '<br>'}</div>`).join('');

  if (isPlaceholder) {
    composeBox.innerHTML = htmlContent;
  } else {
    composeBox.innerHTML = htmlContent + '<div><br></div>' + composeBox.innerHTML;
  }

  ['input', 'keyup', 'change'].forEach(evt =>
    composeBox.dispatchEvent(new Event(evt, { bubbles: true }))
  );

  try {
    const range = document.createRange();
    const sel   = window.getSelection();
    range.selectNodeContents(composeBox);
    range.collapse(false);
    sel.removeAllRanges();
    sel.addRange(range);
  } catch(e) {}
}

// -- Main click handler -----------------------------------------
async function onFabClick() {
  const btn    = document.getElementById('ollama-fab-btn');
  const icon   = document.getElementById('ollama-fab-icon');
  const label  = document.getElementById('ollama-fab-label');
  const status = document.getElementById('ollama-fab-status');

  const emailBody = getEmailBody();
  if (!emailBody) {
    showStatus('No email body found. Open an email first.', 'error');
    return;
  }

  // If model is still empty (Ollama wasn't running at page load), try again now
  if (!settings.model) {
    showStatus('Detecting model...', 'loading');
    await new Promise(resolve => {
      chrome.runtime.sendMessage(
        { action: 'listModels', ollamaUrl: settings.ollamaUrl },
        (res) => {
          if (res && res.success && res.models && res.models.length > 0) {
            settings.model = res.models[0];
            chrome.storage.sync.set({ model: res.models[0] });
          }
          resolve();
        }
      );
    });
    if (!settings.model) {
      showStatus('No model found. Open Ollama popup \u2192 a model will be listed automatically.', 'error');
      icon.textContent  = '&#10060;';
      label.textContent = 'No model \u2014 open popup';
      btn.classList.remove('loading');
      return;
    }
  }

  icon.textContent  = '&#9203;';
  label.textContent = 'Generating...';
  btn.classList.add('loading');
  showStatus('Thinking...', 'loading');

  try {
    const reply = await callOllama(emailBody);

    showStatus('Got reply! Opening compose...', 'success');
    icon.textContent  = '&#9989;';
    label.textContent = 'Injecting...';

    const opened = openReplyBox();
    await delay(opened ? 900 : 200);

    let attempts = 0, injected = false;
    while (attempts < 25 && !injected) {
      const composeBox = findComposeBox();
      if (composeBox) { injectTextIntoCompose(composeBox, reply); injected = true; }
      else { await delay(300); attempts++; }
    }

    if (injected) {
      showStatus('Reply ready in compose!', 'success');
      icon.textContent  = '&#9989;';
      label.textContent = 'Done!';
    } else {
      showReplyModal(reply);
      showStatus('Copy from popup below', 'info');
      icon.textContent  = '&#128203;';
      label.textContent = 'Copied to popup';
    }

  } catch (err) {
    console.error('[Ollama Extension] ERROR:', err);
    let errMsg = err.message || 'Connection error';
    // Surface 403 with clear fix instruction
    if (errMsg.includes('CORS_403') || errMsg.includes('403')) {
      errMsg = '403 blocked. Open popup and run the PowerShell fix shown there.';
    } else if (errMsg.includes('reloaded') || errMsg.includes('F5')) {
      errMsg = 'Extension reloaded - refresh this tab (F5)';
    }
    showStatus(errMsg.slice(0, 90), 'error');
    icon.textContent  = '&#10060;';
    label.textContent = 'Error - check console (F12)';
  }

  setTimeout(() => {
    icon.textContent  = '&#129302;';
    label.textContent = 'Reply with Ollama';
    btn.classList.remove('loading');
    setTimeout(() => { status.style.display = 'none'; }, 3000);
  }, 3000);
}

// -- Call Ollama via Background Worker (bypasses CORS) ----------
async function callOllama(emailBody) {

  // GUARD: If extension was reloaded without refreshing this tab,
  // chrome.runtime becomes invalid -> "sendMessage" crash happens here.
  // Solution: detect it early, show a friendly message.
  if (!isRuntimeValid()) {
    throw new Error(
      'Extension was reloaded. Please refresh this Gmail tab (press F5) and try again.'
    );
  }

  const toneMap = {
    professional: 'professional, formal, and courteous',
    friendly:     'warm, friendly, and conversational',
    concise:      'very short and to-the-point (2-3 sentences max)',
    detailed:     'thorough and detailed, addressing all points clearly',
    assertive:    'confident, direct, and assertive',
    casual:       'casual and relaxed'
  };
  const toneDesc = toneMap[settings.tone] || toneMap.professional;

  const prompt = `You are an expert email writer. Write a ${toneDesc} reply to the following email.
Language: ${settings.language}
Instructions: Write ONLY the email reply body. No subject line. No "To:/From:". Start directly with the content.

Email to reply to:
---
${emailBody}
---

Reply:`;

  console.log('[Ollama Extension] Sending to background worker...');
  console.log('[Ollama Extension] Model:', settings.model, '| URL:', settings.ollamaUrl);

  return new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage(
        {
          action:    'callOllama',
          ollamaUrl: settings.ollamaUrl,
          model:     settings.model,
          prompt
        },
        (response) => {
          // Read lastError immediately (Chrome clears it after this callback)
          const runtimeErr = chrome.runtime && chrome.runtime.lastError;

          if (runtimeErr) {
            const msg = runtimeErr.message || 'Unknown runtime error';
            console.error('[Ollama Extension] Runtime error:', msg);

            if (
              msg.includes('context invalidated') ||
              msg.includes('receiving end does not exist') ||
              msg.includes('The message port closed')
            ) {
              return reject(new Error(
                'Extension reloaded — refresh this Gmail tab (F5) to reconnect.'
              ));
            }
            return reject(new Error('Extension error: ' + msg));
          }

          if (!response) {
            return reject(new Error(
              'No response from background. Is Ollama running? Try: ollama serve'
            ));
          }

          if (response.success) {
            console.log('[Ollama Extension] Got reply, length:', response.reply.length);
            resolve(response.reply);
          } else {
            console.error('[Ollama Extension] API error:', response.error);
            reject(new Error(response.error));
          }
        }
      );
    } catch (syncErr) {
      // sendMessage can throw synchronously when context is dead
      reject(new Error(
        'Extension context lost — refresh this Gmail tab (F5) to reconnect.'
      ));
    }
  });
}

// -- Status message under FAB -----------------------------------
function showStatus(msg, type) {
  const status = document.getElementById('ollama-fab-status');
  if (!status) return;
  status.textContent = msg;
  status.className   = 'ollama-status-' + type;
  status.style.display = 'block';
}

// -- Fallback reply modal ---------------------------------------
function showReplyModal(text) {
  document.getElementById('ollama-modal-overlay')?.remove();

  const overlay = document.createElement('div');
  overlay.id = 'ollama-modal-overlay';
  overlay.innerHTML = `
    <div id="ollama-modal-box">
      <div id="ollama-modal-header">
        <span>&#129302; Ollama Reply - Copy &amp; Paste</span>
        <button id="ollama-modal-close">&#10005;</button>
      </div>
      <textarea id="ollama-modal-text" readonly>${text}</textarea>
      <button id="ollama-modal-copy">&#128203; Copy to Clipboard</button>
    </div>
  `;
  document.body.appendChild(overlay);

  document.getElementById('ollama-modal-close').onclick = () => overlay.remove();
  document.getElementById('ollama-modal-copy').onclick = () => {
    navigator.clipboard.writeText(text).then(() => {
      document.getElementById('ollama-modal-copy').textContent = 'Copied!';
      setTimeout(() => overlay.remove(), 1200);
    });
  };
  overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
}

// -- Utility ----------------------------------------------------
function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

// -- Boot -------------------------------------------------------
function init() {
  createFloatingButton();
  updateFabVisibility();

  // Re-load settings in case popup saved new ones after injection
  loadSettings();

  const navObserver = new MutationObserver(() => updateFabVisibility());
  navObserver.observe(document.body, { childList: true, subtree: true });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  setTimeout(init, 1500);
}